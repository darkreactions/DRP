-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: DRP_db
-- ------------------------------------------------------
-- Server version	5.7.34-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DRP_statsmodel`
--

DROP TABLE IF EXISTS `DRP_statsmodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DRP_statsmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `outputFile` varchar(200) COLLATE utf8_bin NOT NULL,
  `invalid` tinyint(1) NOT NULL,
  `regenerationOf_id` int(11) DEFAULT NULL,
  `container_id` int(11) NOT NULL,
  `startTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `trainingSet_id` int(11) NOT NULL,
  `inputFile` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `DRP_statsmodel_49419660` (`regenerationOf_id`),
  KEY `DRP_statsmodel_082d5760` (`container_id`),
  KEY `DRP_statsmodel_30f843f8` (`trainingSet_id`),
  CONSTRAINT `container_id_refs_id_9932d526` FOREIGN KEY (`container_id`) REFERENCES `DRP_modelcontainer` (`id`),
  CONSTRAINT `regenerationOf_id_refs_id_66b7897acd1fda73` FOREIGN KEY (`regenerationOf_id`) REFERENCES `DRP_statsmodel` (`id`),
  CONSTRAINT `trainingSet_id_refs_id_7c0f2b8b` FOREIGN KEY (`trainingSet_id`) REFERENCES `DRP_dataset` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-19 13:31:58
