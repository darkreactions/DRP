-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: DRP_db
-- ------------------------------------------------------
-- Server version	5.7.34-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DRP_compoundentry`
--

DROP TABLE IF EXISTS `DRP_compoundentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DRP_compoundentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `abbrev` varchar(100) NOT NULL,
  `compound` varchar(100) NOT NULL,
  `CAS_ID` varchar(13) DEFAULT NULL,
  `compound_type` varchar(10) NOT NULL,
  `lab_group_id` int(11) NOT NULL,
  `image_url` varchar(100) NOT NULL,
  `smiles` varchar(255) NOT NULL,
  `mw` varchar(20) NOT NULL,
  `custom` tinyint(1) NOT NULL,
  `calculations_id` int(11) DEFAULT NULL,
  `calculations_failed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `DRP_compoundentry_4306c497` (`lab_group_id`),
  KEY `DRP_compoundentry_2fac1517` (`calculations_id`),
  CONSTRAINT `calculations_id_refs_id_3e74f737` FOREIGN KEY (`calculations_id`) REFERENCES `DRP_cg_calculations` (`id`),
  CONSTRAINT `lab_group_id_refs_id_1015d711` FOREIGN KEY (`lab_group_id`) REFERENCES `DRP_lab_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=876 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-19 13:31:57
