-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: DRP_db
-- ------------------------------------------------------
-- Server version	5.7.34-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DRP_data`
--

DROP TABLE IF EXISTS `DRP_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DRP_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quantity_1` varchar(10) NOT NULL,
  `unit_1` varchar(4) NOT NULL,
  `quantity_2` varchar(10) NOT NULL,
  `unit_2` varchar(4) NOT NULL,
  `quantity_3` varchar(10) NOT NULL,
  `unit_3` varchar(4) NOT NULL,
  `quantity_4` varchar(10) NOT NULL,
  `unit_4` varchar(4) NOT NULL,
  `quantity_5` varchar(10) NOT NULL,
  `unit_5` varchar(4) NOT NULL,
  `ref` varchar(30) NOT NULL,
  `temp` varchar(10) NOT NULL,
  `time` varchar(10) NOT NULL,
  `pH` varchar(5) NOT NULL,
  `slow_cool` varchar(10) NOT NULL,
  `leak` varchar(10) NOT NULL,
  `outcome` varchar(1) NOT NULL,
  `purity` varchar(1) NOT NULL,
  `notes` varchar(200) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lab_group_id` int(11) NOT NULL,
  `calculations_id` int(11) DEFAULT NULL,
  `is_valid` tinyint(1) NOT NULL,
  `duplicate_of` varchar(12) DEFAULT NULL,
  `recommended` varchar(10) NOT NULL,
  `calculated_time` tinyint(1) NOT NULL,
  `calculated_temp` tinyint(1) NOT NULL,
  `calculated_pH` tinyint(1) NOT NULL,
  `atoms` varchar(30) NOT NULL,
  `public` tinyint(1) NOT NULL,
  `creation_time_dt` datetime DEFAULT NULL,
  `reactant_fk_1_id` int(11) DEFAULT NULL,
  `reactant_fk_2_id` int(11) DEFAULT NULL,
  `reactant_fk_3_id` int(11) DEFAULT NULL,
  `reactant_fk_4_id` int(11) DEFAULT NULL,
  `reactant_fk_5_id` int(11) DEFAULT NULL,
  `persistent_homologies` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `DRP_data_6340c63c` (`user_id`),
  KEY `DRP_data_4306c497` (`lab_group_id`),
  KEY `DRP_data_2fac1517` (`calculations_id`),
  KEY `DRP_data_83d61a2e` (`reactant_fk_1_id`),
  KEY `DRP_data_8823ecb9` (`reactant_fk_2_id`),
  KEY `DRP_data_26681052` (`reactant_fk_3_id`),
  KEY `DRP_data_26e2dcfd` (`reactant_fk_4_id`),
  KEY `DRP_data_e8992c44` (`reactant_fk_5_id`),
  CONSTRAINT `calculations_id_refs_id_50610c2a` FOREIGN KEY (`calculations_id`) REFERENCES `DRP_datacalc` (`id`),
  CONSTRAINT `lab_group_id_refs_id_65eabecd` FOREIGN KEY (`lab_group_id`) REFERENCES `DRP_lab_group` (`id`),
  CONSTRAINT `reactant_fk_1_id_refs_id_55e1c78c` FOREIGN KEY (`reactant_fk_1_id`) REFERENCES `DRP_compoundentry` (`id`),
  CONSTRAINT `reactant_fk_2_id_refs_id_55e1c78c` FOREIGN KEY (`reactant_fk_2_id`) REFERENCES `DRP_compoundentry` (`id`),
  CONSTRAINT `reactant_fk_3_id_refs_id_55e1c78c` FOREIGN KEY (`reactant_fk_3_id`) REFERENCES `DRP_compoundentry` (`id`),
  CONSTRAINT `reactant_fk_4_id_refs_id_55e1c78c` FOREIGN KEY (`reactant_fk_4_id`) REFERENCES `DRP_compoundentry` (`id`),
  CONSTRAINT `reactant_fk_5_id_refs_id_55e1c78c` FOREIGN KEY (`reactant_fk_5_id`) REFERENCES `DRP_compoundentry` (`id`),
  CONSTRAINT `user_id_refs_id_008e14e8` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9074 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-19 13:31:57
