-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: DRP_restore
-- ------------------------------------------------------
-- Server version	5.7.34-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DRP_ordrxndescriptorvalue`
--

DROP TABLE IF EXISTS `DRP_ordrxndescriptorvalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DRP_ordrxndescriptorvalue` (
  `value` int(11) DEFAULT NULL,
  `descriptor_id` int(11) NOT NULL,
  `reaction_id` int(11) NOT NULL DEFAULT '1',
  `uid` varchar(36) COLLATE utf8_bin NOT NULL,
  `rater_id` int(11) NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `DRP_ordrxndescriptorvalue_reaction_id_4866f36856fe4611_uniq` (`reaction_id`,`descriptor_id`),
  UNIQUE KEY `DRP_ordrxndescriptorvalue_uid_7fa297ca51fff6b8_uniq` (`uid`),
  KEY `DRP_ordrxndescriptorvalue_5ffc53df` (`descriptor_id`),
  KEY `DRP_ordrxndescriptorvalue_b8569f73` (`reaction_id`),
  KEY `DRP_ordrxndescriptorvalue_9e4fc8b5` (`rater_id`),
  CONSTRAINT `descriptor_id_refs_descriptor_ptr_id_1f68aacf9535bb30` FOREIGN KEY (`descriptor_id`) REFERENCES `DRP_ordinaldescriptor` (`descriptor_ptr_id`),
  CONSTRAINT `reaction_id_refs_id_36600d9a2c5e2732` FOREIGN KEY (`reaction_id`) REFERENCES `DRP_reaction` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-19 13:33:59
