-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: DRP_restore
-- ------------------------------------------------------
-- Server version	5.7.34-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DRP_compound_chemicalClasses`
--

DROP TABLE IF EXISTS `DRP_compound_chemicalClasses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DRP_compound_chemicalClasses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `compound_id` int(11) NOT NULL,
  `chemicalclass_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DRP_compound_chemicalClasses_compound_id_6a2181f7ea924173_uniq` (`compound_id`,`chemicalclass_id`),
  KEY `DRP_compound_chemicalClasses_bc0eaa77` (`compound_id`),
  KEY `DRP_compound_chemicalClasses_8c3585f9` (`chemicalclass_id`),
  CONSTRAINT `chemicalclass_id_refs_id_76fa313d7ff5de6a` FOREIGN KEY (`chemicalclass_id`) REFERENCES `DRP_chemicalclass` (`id`),
  CONSTRAINT `compound_id_refs_id_4b3c15072f8edf16` FOREIGN KEY (`compound_id`) REFERENCES `DRP_compound` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-19 13:33:57
