-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: DRP_restore
-- ------------------------------------------------------
-- Server version	5.7.34-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DRP_performedreaction`
--

DROP TABLE IF EXISTS `DRP_performedreaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DRP_performedreaction` (
  `reaction_ptr_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `performedDateTime` datetime DEFAULT NULL,
  `recommendation_id` int(11) DEFAULT NULL,
  `legacyRecommendedFlag` tinyint(1) DEFAULT NULL,
  `valid` tinyint(1) NOT NULL,
  `public` tinyint(1) NOT NULL,
  `duplicateOf_id` int(11) DEFAULT NULL,
  `reference` varchar(40) COLLATE utf8_bin NOT NULL,
  `insertedDateTime` datetime NOT NULL,
  `performedBy_id` int(11) DEFAULT NULL,
  `legacyID` int(11) DEFAULT NULL,
  `legacyRef` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `convertedLegacyRef` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `labBookPage` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`reaction_ptr_id`),
  UNIQUE KEY `legacyID` (`legacyID`),
  KEY `DRP_performedreaction_6340c63c` (`user_id`),
  KEY `DRP_performedreaction_354c84b7` (`recommendation_id`),
  KEY `DRP_performedreaction_44d03b62` (`duplicateOf_id`),
  KEY `DRP_performedreaction_4c93867c` (`performedBy_id`),
  CONSTRAINT `DRP_performedrea_performedBy_id_3e44fa990f22acbb_fk_auth_user_id` FOREIGN KEY (`performedBy_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `bfa232e3fab31365b6a6494b118a97f8` FOREIGN KEY (`duplicateOf_id`) REFERENCES `DRP_performedreaction` (`reaction_ptr_id`),
  CONSTRAINT `reaction_ptr_id_refs_id_234695c16b7d42fc` FOREIGN KEY (`reaction_ptr_id`) REFERENCES `DRP_reaction` (`id`),
  CONSTRAINT `recommendation_id_refs_reaction_ptr_id_6f4b962fd3d8fc2c` FOREIGN KEY (`recommendation_id`) REFERENCES `DRP_recommendedreaction` (`reaction_ptr_id`),
  CONSTRAINT `user_id_refs_id_6540dc59e13e1e55` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-19 13:33:59
